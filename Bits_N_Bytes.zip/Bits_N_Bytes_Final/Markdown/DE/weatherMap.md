# Wetterkarte

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

# Wetterkarte Nutzen

Da wir unser Dashboard universell gestalten wollten, brauchten wir auch gewisse
Funktionen, die nicht im direkten Zusammenhang zur Informatik stehen, deswegen
dachten wir uns. Warum nicht eine Wetter Map einbauen, die verschiedene
Funktionen hat, wie Windströme und Satellitenbilder. Die Wetter Map ist dazu da,
dass man stets informiert ist, welches Wetter wir haben

# Wetterkarte, wie sie gemacht wurde

Die Wetter Map wurde mittels einem `<iframe>` in unserem Dashboard
implementiert. Das heisst wir holen die Wetter Map von einer anderen Seite, die
sie sehr wahrscheinlich mit einer API gemacht hat, die von Ihrer Wetterstation
die nötigen Daten bekommt.
