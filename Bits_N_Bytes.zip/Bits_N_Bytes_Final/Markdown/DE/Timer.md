# Timer

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

# Zweck

Da wir unser Dashboard universell gestalten wollten, brauchten wir auch gewisse
Funktionen, die nicht im direkten Zusammenhang zur Informatik stehen. Für ein gutes Zeitmanagement, braucht es auch einen Timer. 

# Anwenden
Im Dropdown Medü wählt man Strunde, Minute oder Sekunde aus, gibt eine Zahl ein und setzt diese in den Timer ein. Danach kann der Timer gestarted, Pausiert und Zurückgesetzt werden.

# Timer, wie sie gemacht wurde

Der Timer wurde mit einer Vorlage von [**Codingnepalweb.com**](https://Codingnepalweb.com) erstellt. Sie wurde mit HTML, CSS und JavaScript geschrieben.