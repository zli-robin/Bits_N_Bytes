## Grundlagen

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

**Um das Dashboard zu verwenden, gehen Sie bitte wie folgt vor:**

1. Klicke mit der rechten Maustaste auf den Hintergrund, um das Customizer-Menü zu öffnen.
2. Wählen im Customizer-Menü das Widget, das Du ein- oder ausblenden möchten.
3. Um ein Widget zu verschieben, klicke auf den grauen Rand des Widgets und ziehen es.

Das war's schon! Du solltest nun in der Lage sein, Das Dashboard nach deinen Wünschen anzupassen und zu gestalten.