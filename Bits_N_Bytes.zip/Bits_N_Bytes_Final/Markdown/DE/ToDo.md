# To-do-Liste

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

# To-do Zweck

In dieser ToDo-App können Sie Ihre Aufgaben einfach hinzufügen, bearbeiten, löschen oder als erledigt markieren. Es gibt auch eine Filter-Schaltfläche, die Ihnen hilft, die Aufgaben entsprechend zu filtern. Die Aufgaben, die Sie dieser ToDo-App hinzugefügt haben, werden im lokalen Speicher des Browsers gespeichert, so dass sie beim Aktualisieren der Seite oder Schließen der Registerkarte nicht entfernt werden. Sie können auch alle Aufgaben auf einmal löschen, indem Sie auf die Schaltfläche "Alle löschen" klicken.

# To-Do, wie sie gemacht wurde

Die Aufgabenliste wurde mit einer Vorlage von Codingnepalweb.com erstellt. Sie wurde mit HTML, CSS und JavaScript geschrieben.
