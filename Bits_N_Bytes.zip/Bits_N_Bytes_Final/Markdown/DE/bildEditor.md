# Bild-Editor

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

# Zweck
Anleitung zum Bildeditor

# Anwenden
Um den Bildeditor sehen zu können, kann man einen irgenwo auf der Websiteoberfläche einen
Rechtsklick machen und anschliessend auf "Kreationen" und anschliessend auf "Bild Editor" klicken.
Auf dem Edior kann man dann ein gewähltes Bild hochladen und dieses dann mit den verschiedenen
Funktionen auf dem Fenster bearbeiten.


