# Rechner (Calculator)

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

# Zweck
Anleitung zum Taschenrechner

# Anwenden
Um den Taschenrechner sehen zu können, kann man irgendwo auf der Websiteoberfläche einen
Rechtsklick machen und anschliessend auf "Tools" und anschliessend auf "Rechner" klicken.
Auf dem Taschenrechner kann man dannn anschliessend die gewünschten Rechnungen vornehmen und ausrechnen.
