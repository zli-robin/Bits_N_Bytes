# Radio

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

# Zweck

Da wir unser Dashboard universell gestalten wollten, brauchten wir auch gewisse
Funktionen, die nicht im direkten Zusammenhang zur Informatik stehen. Für eine gute Stimmung, braucht es auch Musik oder in diesem fall einen Radio. 

# Anwenden
Im Menü kann man unter Musik den Gewünschten Radio Sender auswählen. Danach wird ein Widget angezeit, bei dem man eventuell die Cookies akzeptieren muss. Danach kann man auf den Play Button klicken und Musik geniessen.

# Radio, wie er gemacht wurde

Die Radios wurden mit einem IFRAME von [**Energy.ch**](https://energy.ch/) hinzugefügt.