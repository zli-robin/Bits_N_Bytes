# Uhr

🇨🇭 **Deutsch** - Feel free to change the language of the Markdown by pressing your preferred button in the navbar!

# Zweck

Da wir unser Dashboard universell gestalten wollten, brauchten wir auch gewisse
Funktionen, die nicht im direkten Zusammenhang zur Informatik stehen. Für einen guten überblick und Zeitmanagement, braucht es auch eine Digitale Uhr. 

# Uhr, wie sie gemacht wurde

Die Uhr wurde mittels einem `<iframe>` in unserem Dashboard implementiert. Das heisst wir holen die Uhrzeit von einer anderen Seite, in diesem Fall von der Webseite [**uhrzeit123.de**](https://uhrzeit123.de/).
