# Radio

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# Purpose

Since we wanted to make our dashboard universal, we also needed certain
functions that are not directly related to computer science. For a good mood, you also need music or in this case a radio. 

# Apply
In the menu, you can select the desired radio station under Music. After that a widget will be displayed, where you may have to accept the cookies. After that you can click on the play button and enjoy the music.

# Radio as it was made

The radios were added with an IFRAME from [**Energy.ch**](https://energy.ch/).