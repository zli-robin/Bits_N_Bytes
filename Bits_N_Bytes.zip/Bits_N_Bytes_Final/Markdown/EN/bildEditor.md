# Bild-Editor

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# Purpose
Image editor guide

# How to use
To see the image editor, you can right-click somewhere on the website interface and then
right-click anywhere on the website interface and then click on "Creations" and then on "Image Editor".
On the Edior you can then upload a selected image and edit it with the various functions on the window.
functions on the window.


