# Weather map

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# Weather map utility

Since we wanted to make our dashboard universal, we also needed certain
functions that are not directly related to IT, so we thought why not include a
weather map that has various functions, such as wind currents and satellite
images. The weather map is there to keep you informed of what the weather is
like.

# Weather map, how it was made

The weather map was implemented in our dashboard using an `<iframe>`. This means
that we get the weather map from another site, which most likely made it with an
API that gets the necessary data from your weather station.
