## Password
If you want to generate a secure password you can do this on our dashboard, BitsNBytes offers a convinient way to generate password, by simply using our menu.

### Guide on how to use it
By `right-clicking` any where on our page you can toggle the options/tools menu, to select the password generator form this menu you must do the following click on `Tools` then `Password` this will open the password generator a widget will then appear and you can adjust the `password length` by sliding the indicator to right for longest password and to the left for shortest password. Additionally you can set your password settings to only use `lowercase (a-z)` or only use `Uppercase (A -Z)` you can also additionally add `Numbers (0-9)`, `Symbols (!"+*)` and exclude duplicates and include spaces.

### Guide on how to modify it
To modify the password generator you will need to navigate to `--Bits_N_Bytes_Final--/widgets/passwordgen` there you will find the following files `passgen.css, passgen.html and passgen.js` if you want to adjust how the widget looks feel free to modify/adjust the `html` and `css` to your likings, however if you want to modify/adjust the password generation in itself you must modify/adjust the `passgen.js` file, because this file actually handels the work.

