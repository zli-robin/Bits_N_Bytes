# Timer

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# Purpose

Since we wanted to make our dashboard universal, we also needed certain
functions that are not directly related to IT. For a good time management, we also need a timer. 

# How to use
In the dropdown menu you select hour, minute or second, enter a number and set it in the timer. After that the timer can be started, paused and reset.

# Timer as it was made

The timer was made with a template from [**Codingnepalweb.com**](https://Codingnepalweb.com). It was written with HTML, CSS and JavaScript.