# Rechner (Calculator)

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# Purpose
Guide to the calculator

# Use
To see the calculator, you can right-click anywhere on the website interface and then click on
right-click anywhere on the website interface and then click on "Tools" and then on "Calculator".
On the calculator you can then make the desired calculations and calculate.
