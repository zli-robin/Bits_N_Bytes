# To-do list

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# To-do Usage

In this todo app, you can easily add, edit, delete or mark as complete your tasks. There are filters button too that helps you to filter the tasks accordingly. The tasks you added to this todo app will be stored in the browser’s local storage so, they won’t be removed on page refresh or tab close. You can also delete all tasks at once by clicking on the “Clear All” button.

# Wetterkarte, how it was made

The to-do list was included using a template from [**Codingnepalweb.com**](https://Codingnepalweb.com). It was written with HTML, CSS and JavaScript.
