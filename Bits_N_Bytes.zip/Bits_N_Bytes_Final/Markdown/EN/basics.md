## Basics

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

**To use the dashboard, please do the following:**

1. right click on the background to open the Customizer menu.
2. in the Customizer menu, select the widget you want to show or hide.
3. to move a widget, click on the gray border of the widget and drag it.

That's it! You should now be able to customize and design your dashboard to your liking.