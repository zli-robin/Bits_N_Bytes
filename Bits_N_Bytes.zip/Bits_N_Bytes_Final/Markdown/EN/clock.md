# Clock

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# Purpose

Since we wanted to make our dashboard universal, we also needed certain
functions that are not directly related to computer science. For a good overview and time management, we also need a digital clock. 

# Clock, how it was made

The Clock was implemented in our dashboard using an `<iframe>`. That means we get the time from another site, in this case from the website [**uhrzeit123.de**](https://uhrzeit123.de/).
