## Text to File
Easily create text or markdown files by using our Dashboard, BitsNBytes. It offers a simple way to create text files, in this explain page I will show you how to use it and most importantly how to modify the code.

### Guide on how to use it
As every other option on our dashboard it can be accessed through the options/tool menu. The options/tool menu is opened by `rightclicking` anywhere on the page, given that it, isn't on a widget. To access the Text to File converter you must do the following click on `Kreationen > Text zu Datei`. Now you will see a new widget on your, it now prompts you to input text. After you inserted what you want you can input your desired filename and your desired fileformat.

### Guide on how to modify it
Now onto how to modify the creation to text to file.

To modify the text to file converter you will need to navigate to `--Bits_N_Bytes_Final--/widgets/file save` there you will find the following files `file.css, file.html and file.js` if you want to adjust how the widget looks feel free to modify/adjust the `html` and `css` to your likings, however if you want to modify/adjust the conversion in itself you must modify/adjust the `file.js` file, because this file actually handels the work.