# Threatmap

🇬🇧 **English** - Fühlen dich frei, die Sprache des Markdowns zu ändern, indem du deine bevorzugte Sprache in der Navigationsleiste drückst!

# Threatmap, what is it?

Threatmap is a tool developed by IT and security companies,
to help companies manage and monitor their network security.
security. It provides automated detection protocols for many types of
available on the market. With this tool
organisations not only detect potential threats, but also perform analytics to
to detect corresponding actions. In this way
identify risks in real time and take timely action to protect their
take timely action to protect their networks.

# From where?

Kaspersky's Threatmap is an easy-to-use, web-based tool that
provides detailed information about current cyber threats, as seen
below. The tool has interactive heat maps that allow you to get a
complete overview of the global threat situation. It
provides users with detailed analysis via real-time threat intelligence,
attack vectors and vulnerabilities, and trends in malware and exploit proliferation.
of malware and exploits.